import 'package:flutter/material.dart';
import '../shared/theme/nx_theme.dart';
import '../features/home/presentation/nx_home_screen.dart';

class NXApp extends StatelessWidget {
  const NXApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'NX Style',
      theme: NXTheme.light(),
      home: const NXHomeScreen(),
    );
  }
}
