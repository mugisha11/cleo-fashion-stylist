import 'package:flutter/material.dart';

class NXColors {
  static const bgSpaceTop = Color(0xFF07142F);
  static const bgSpaceMid = Color(0xFF0B1B3A);
  static const panel = Color(0xFFF6F9FF);
  static const panelAlt = Color(0xFFEEF3FF);

  static const primary = Color(0xFF1F4AA8);
  static const primaryDark = Color(0xFF132E6A);
  static const accentGlow = Color(0xFF4DA3FF);

  static const silver = Color(0xFFC9D2E3);
  static const silverDark = Color(0xFF9EACC3);

  static const textPrimary = Color(0xFF0B1B3A);
  static const textSecondary = Color(0xFF3D4B66);
}

class NXGradients {
  static const header = LinearGradient(
    colors: [NXColors.bgSpaceTop, NXColors.bgSpaceMid, NXColors.panel],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  static const primary = LinearGradient(
    colors: [NXColors.primary, NXColors.primaryDark],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );
}

class NXTheme {
  static ThemeData light() {
    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: NXColors.panel,
      colorScheme: ColorScheme.fromSeed(seedColor: NXColors.primary),
      textTheme: const TextTheme(
        headlineSmall: TextStyle(
          fontSize: 28,
          fontWeight: FontWeight.w600,
          color: NXColors.textPrimary,
        ),
        titleMedium: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w500,
          color: NXColors.textSecondary,
        ),
        bodyMedium: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w400,
          color: NXColors.textPrimary,
        ),
        labelMedium: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w500,
          color: NXColors.textSecondary,
        ),
      ),
    );
  }
}
