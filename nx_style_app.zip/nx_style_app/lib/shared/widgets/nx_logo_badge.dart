import 'package:flutter/material.dart';
import '../theme/nx_theme.dart';

class NXLogoBadge extends StatelessWidget {
  final double size;
  final bool glow;

  const NXLogoBadge({super.key, this.size = 120, this.glow = true});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const RadialGradient(
          colors: [
            Color(0xFFE8EEF9),
            NXColors.silver,
            NXColors.silverDark,
            NXColors.accentGlow,
          ],
          stops: [0.0, 0.40, 0.70, 1.0],
        ),
        boxShadow: glow
            ? [
                BoxShadow(
                  color: NXColors.accentGlow.withOpacity(0.55),
                  blurRadius: 18,
                )
              ]
            : null,
      ),
      child: Center(
        child: Text(
          'NX',
          style: TextStyle(
            fontSize: size * 0.28,
            fontWeight: FontWeight.w800,
            color: NXColors.bgSpaceMid,
            letterSpacing: 1.0,
          ),
        ),
      ),
    );
  }
}
