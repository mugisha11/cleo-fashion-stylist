import 'package:flutter/material.dart';
import 'app/nx_app.dart';

void main() {
  runApp(const NXApp());
}
