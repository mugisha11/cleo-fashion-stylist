import 'package:flutter/material.dart';
import '../../../shared/theme/nx_theme.dart';
import '../../../shared/widgets/glass_card.dart';
import '../../../shared/widgets/nx_logo_badge.dart';

class NXHomeScreen extends StatefulWidget {
  const NXHomeScreen({super.key});

  @override
  State<NXHomeScreen> createState() => _NXHomeScreenState();
}

class _NXHomeScreenState extends State<NXHomeScreen> {
  int _navIndex = 2;
  int _tabIndex = 0;

  final _tabs = const ['Date', 'Wedding', 'Dining Out', 'Daily', 'Interview'];
  final _actions = const ['Create Outfits', 'Saved Outfits', 'Shopping'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: _BottomNav(
        currentIndex: _navIndex,
        onTap: (i) => setState(() => _navIndex = i),
      ),
      body: Container(
        decoration: const BoxDecoration(gradient: NXGradients.header),
        child: SafeArea(
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                children: [
                  const SizedBox(height: 10),
                  _TopRow(),
                  const SizedBox(height: 14),
                  const NXLogoBadge(size: 120),
                  const SizedBox(height: 14),
                  Text(
                    'Arjün Patel',
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          color: NXColors.textPrimary,
                        ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Your Personal AI Style Consultant',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 14),
                  const _PortraitPlaceholder(),
                  const SizedBox(height: 14),
                  const _PromptBar(),
                  const SizedBox(height: 14),
                  _OccasionTabs(
                    tabs: _tabs,
                    selectedIndex: _tabIndex,
                    onChanged: (i) => setState(() => _tabIndex = i),
                  ),
                  const SizedBox(height: 16),
                  _PrimaryActionsRow(actions: _actions),
                  const SizedBox(height: 18),
                  _SectionTitleRow(left: 'Inspiration', right: 'Fits Your Wardrobe'),
                  const SizedBox(height: 12),
                  const _DualCards(),
                  const SizedBox(height: 140),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _TopRow extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: const [
        _IconCircle(icon: Icons.menu_rounded),
        _IconCircle(icon: Icons.notifications_none_rounded),
      ],
    );
  }
}

class _IconCircle extends StatelessWidget {
  final IconData icon;
  const _IconCircle({required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 46,
      height: 46,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.white.withOpacity(0.18),
        border: Border.all(color: Colors.white.withOpacity(0.25), width: 1),
      ),
      child: Icon(icon, color: Colors.white, size: 24),
    );
  }
}

class _PortraitPlaceholder extends StatelessWidget {
  const _PortraitPlaceholder();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 220,
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: Colors.white.withOpacity(0.65),
        boxShadow: const [
          BoxShadow(
            color: Color(0x1A0B1B3A),
            blurRadius: 18,
            offset: Offset(0, 8),
          )
        ],
        border: Border.all(color: NXColors.silver.withOpacity(0.6), width: 1),
      ),
      child: const Center(
        child: Text(
          'Portrait Image Placeholder',
          style: TextStyle(color: NXColors.textSecondary),
        ),
      ),
    );
  }
}

class _PromptBar extends StatelessWidget {
  const _PromptBar();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: NXGradients.primary,
        boxShadow: const [
          BoxShadow(
            color: Color(0x2E0B1B3A),
            blurRadius: 22,
            offset: Offset(0, 10),
          )
        ],
      ),
      child: Row(
        children: const [
          NXLogoBadge(size: 42, glow: false),
          SizedBox(width: 12),
          Expanded(
            child: Text(
              'Ask NX for outfit suggestions',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Icon(Icons.mic_rounded, color: Colors.white),
        ],
      ),
    );
  }
}

class _OccasionTabs extends StatelessWidget {
  final List<String> tabs;
  final int selectedIndex;
  final ValueChanged<int> onChanged;

  const _OccasionTabs({
    required this.tabs,
    required this.selectedIndex,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.70),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: NXColors.silver.withOpacity(0.7), width: 1),
        boxShadow: const [
          BoxShadow(
            color: Color(0x160B1B3A),
            blurRadius: 16,
            offset: Offset(0, 8),
          )
        ],
      ),
      child: Row(
        children: List.generate(tabs.length, (i) {
          final active = i == selectedIndex;
          return Expanded(
            child: GestureDetector(
              onTap: () => onChanged(i),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: active ? Colors.white : Colors.transparent,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      tabs[i],
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontWeight: active ? FontWeight.w700 : FontWeight.w600,
                        color: NXColors.textPrimary,
                        fontSize: 13,
                      ),
                    ),
                    const SizedBox(height: 6),
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 220),
                      height: 3,
                      width: active ? 34 : 0,
                      decoration: BoxDecoration(
                        color: NXColors.primary,
                        borderRadius: BorderRadius.circular(99),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

class _PrimaryActionsRow extends StatelessWidget {
  final List<String> actions;
  const _PrimaryActionsRow({required this.actions});

  IconData _iconFor(String label) {
    if (label.contains('Create')) return Icons.auto_awesome_rounded;
    if (label.contains('Saved')) return Icons.bookmark_rounded;
    return Icons.shopping_bag_rounded;
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: actions.map((a) {
        return Expanded(
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 6),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: NXGradients.primary,
              boxShadow: const [
                BoxShadow(
                  color: Color(0x2E0B1B3A),
                  blurRadius: 18,
                  offset: Offset(0, 10),
                )
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withOpacity(0.12),
                    border: Border.all(color: Colors.white.withOpacity(0.22), width: 1),
                  ),
                  child: Icon(_iconFor(a), color: Colors.white, size: 22),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    a,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 13,
                    ),
                  ),
                ),
                const Icon(Icons.chevron_right_rounded, color: Colors.white),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _SectionTitleRow extends StatelessWidget {
  final String left;
  final String right;
  const _SectionTitleRow({required this.left, required this.right});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Text(
            left,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
          ),
        ),
        Expanded(
          child: Text(
            right,
            textAlign: TextAlign.right,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
          ),
        ),
      ],
    );
  }
}

class _DualCards extends StatelessWidget {
  const _DualCards();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: const [
        Expanded(
          child: _ImageCard(
            caption: 'Elevated formal confidence',
          ),
        ),
        SizedBox(width: 12),
        Expanded(
          child: _ImageCard(
            caption: 'Smart casual made effortless',
          ),
        ),
      ],
    );
  }
}

class _ImageCard extends StatelessWidget {
  final String caption;
  const _ImageCard({required this.caption});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 220,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: Colors.white.withOpacity(0.85),
        border: Border.all(color: NXColors.silver.withOpacity(0.7), width: 1),
        boxShadow: const [
          BoxShadow(
            color: Color(0x160B1B3A),
            blurRadius: 18,
            offset: Offset(0, 10),
          )
        ],
      ),
      child: Column(
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
                color: NXColors.panelAlt,
              ),
              child: const Center(
                child: Text(
                  'Image Placeholder',
                  style: TextStyle(color: NXColors.textSecondary),
                ),
              ),
            ),
          ),
          Container(
            height: 46,
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              borderRadius: const BorderRadius.vertical(bottom: Radius.circular(16)),
              color: Colors.white.withOpacity(0.95),
              border: Border(
                top: BorderSide(color: NXColors.silver.withOpacity(0.55), width: 1),
              ),
            ),
            child: Text(
              caption,
              style: const TextStyle(fontWeight: FontWeight.w600),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}

class _BottomNav extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;

  const _BottomNav({required this.currentIndex, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 98,
      padding: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: NXColors.silver.withOpacity(0.65), width: 1)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0F0B1B3A),
            blurRadius: 18,
            offset: Offset(0, -6),
          )
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _NavItem(
            index: 0,
            currentIndex: currentIndex,
            label: 'Try On',
            icon: Icons.camera_alt_outlined,
            onTap: onTap,
          ),
          _NavItem(
            index: 1,
            currentIndex: currentIndex,
            label: 'Wardrobe',
            icon: Icons.checkroom_outlined,
            onTap: onTap,
          ),
          _HomeNavItem(
            index: 2,
            currentIndex: currentIndex,
            onTap: onTap,
          ),
          _NavItem(
            index: 3,
            currentIndex: currentIndex,
            label: 'Friends Space',
            icon: Icons.group_outlined,
            onTap: onTap,
          ),
          _NavItem(
            index: 4,
            currentIndex: currentIndex,
            label: 'Profile',
            icon: Icons.person_outline,
            onTap: onTap,
          ),
        ],
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final int index;
  final int currentIndex;
  final String label;
  final IconData icon;
  final ValueChanged<int> onTap;

  const _NavItem({
    required this.index,
    required this.currentIndex,
    required this.label,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final active = index == currentIndex;
    final color = active ? NXColors.primary : NXColors.textSecondary;

    return GestureDetector(
      onTap: () => onTap(index),
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 68,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 26),
            const SizedBox(height: 6),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: color,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}

class _HomeNavItem extends StatelessWidget {
  final int index;
  final int currentIndex;
  final ValueChanged<int> onTap;

  const _HomeNavItem({
    required this.index,
    required this.currentIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final active = index == currentIndex;

    return GestureDetector(
      onTap: () => onTap(index),
      behavior: HitTestBehavior.opaque,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Transform.translate(
            offset: const Offset(0, -12),
            child: NXLogoBadge(size: 76, glow: active),
          ),
          Transform.translate(
            offset: const Offset(0, -12),
            child: Text(
              'Home',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: active ? NXColors.primary : NXColors.textSecondary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
