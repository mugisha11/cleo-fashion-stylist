NX Style App

Run steps

1. Ensure Flutter is installed
2. In this folder, run: flutter pub get
3. Run on a device or emulator: flutter run

Project structure

lib/app
  nx_app.dart                 App root and routing

lib/features/home/presentation
  nx_home_screen.dart         Home landing UI

lib/shared/theme
  nx_theme.dart               Colors, gradients, text styles

lib/shared/widgets
  glass_card.dart             Reusable glass panel widget
  nx_logo_badge.dart          NX logo placeholder widget

assets/images
  Place your NX logo PNG here if you want, for example nx_logo.png
